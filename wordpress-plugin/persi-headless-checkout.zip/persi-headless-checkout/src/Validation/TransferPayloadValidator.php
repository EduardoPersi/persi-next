<?php

namespace Persi\HeadlessCheckout\Validation;

defined( 'ABSPATH' ) || exit;

final class TransferPayloadValidator {
	private const FORBIDDEN_FIELDS = array(
		'price',
		'subtotal',
		'discount',
		'shippingCost',
		'tax',
		'total',
		'stock',
		'currency',
	);

	public function validate_json( string $raw_body ): array {
		if ( '' === $raw_body || strlen( $raw_body ) > 32768 ) {
			throw new ValidationException( 'invalid_body_size' );
		}

		try {
			$payload = json_decode( $raw_body, true, 32, JSON_THROW_ON_ERROR );
		} catch ( \JsonException $exception ) {
			throw new ValidationException( 'invalid_json' );
		}

		if ( ! is_array( $payload ) || array_values( $payload ) === $payload ) {
			throw new ValidationException( 'invalid_payload' );
		}

		$this->reject_forbidden_fields( $payload );
		$this->assert_exact_keys( $payload, array( 'items', 'couponCodes', 'shippingMethod' ) );

		return array(
			'items'          => $this->validate_items( $payload['items'] ),
			'couponCodes'    => $this->validate_coupon_codes( $payload['couponCodes'] ),
			'shippingMethod' => $this->validate_shipping_method( $payload['shippingMethod'] ),
		);
	}

	private function validate_items( $items ): array {
		if (
			! is_array( $items )
			|| array_values( $items ) !== $items
			|| count( $items ) < 1
			|| count( $items ) > 100
		) {
			throw new ValidationException( 'invalid_items' );
		}

		$validated = array();

		foreach ( $items as $item ) {
			if ( ! is_array( $item ) || array_values( $item ) === $item ) {
				throw new ValidationException( 'invalid_item' );
			}

			$this->reject_forbidden_fields( $item );
			$this->assert_exact_keys( $item, array( 'productId', 'variationId', 'quantity' ) );

			if ( ! is_int( $item['productId'] ) || $item['productId'] < 1 ) {
				throw new ValidationException( 'invalid_product_id' );
			}

			if ( ! is_int( $item['variationId'] ) || $item['variationId'] < 0 ) {
				throw new ValidationException( 'invalid_variation_id' );
			}

			if ( ! is_int( $item['quantity'] ) || $item['quantity'] < 1 || $item['quantity'] > 999 ) {
				throw new ValidationException( 'invalid_quantity' );
			}

			$validated[] = array(
				'productId'   => $item['productId'],
				'variationId' => $item['variationId'],
				'quantity'    => $item['quantity'],
			);
		}

		return $validated;
	}

	private function validate_coupon_codes( $coupon_codes ): array {
		if (
			! is_array( $coupon_codes )
			|| array_values( $coupon_codes ) !== $coupon_codes
			|| count( $coupon_codes ) > 20
		) {
			throw new ValidationException( 'invalid_coupon_codes' );
		}

		$validated = array();

		foreach ( $coupon_codes as $coupon_code ) {
			if ( ! is_string( $coupon_code ) || $this->string_length( $coupon_code ) > 100 ) {
				throw new ValidationException( 'invalid_coupon_code' );
			}

			$trimmed = trim( $coupon_code );

			if ( '' === $trimmed || preg_match( '/[\x00-\x1F\x7F]/', $trimmed ) ) {
				throw new ValidationException( 'invalid_coupon_code' );
			}

			$validated[] = $trimmed;
		}

		return $validated;
	}

	private function validate_shipping_method( $shipping_method ): array {
		if ( ! is_array( $shipping_method ) || array_values( $shipping_method ) === $shipping_method ) {
			throw new ValidationException( 'invalid_shipping_method' );
		}

		$this->reject_forbidden_fields( $shipping_method );
		$this->assert_exact_keys( $shipping_method, array( 'rateId', 'packageIndex' ) );

		if (
			! is_string( $shipping_method['rateId'] )
			|| $this->string_length( $shipping_method['rateId'] ) > 200
			|| preg_match( '/[\x00-\x1F\x7F]/', $shipping_method['rateId'] )
		) {
			throw new ValidationException( 'invalid_rate_id' );
		}

		if (
			! is_int( $shipping_method['packageIndex'] )
			|| $shipping_method['packageIndex'] < 0
			|| $shipping_method['packageIndex'] > 20
		) {
			throw new ValidationException( 'invalid_package_index' );
		}

		return array(
			'rateId'       => $shipping_method['rateId'],
			'packageIndex' => $shipping_method['packageIndex'],
		);
	}

	private function assert_exact_keys( array $value, array $allowed_keys ): void {
		$actual_keys = array_keys( $value );
		sort( $actual_keys );
		sort( $allowed_keys );

		if ( $actual_keys !== $allowed_keys ) {
			throw new ValidationException( 'unknown_or_missing_property' );
		}
	}

	private function reject_forbidden_fields( array $value ): void {
		foreach ( self::FORBIDDEN_FIELDS as $field ) {
			if ( array_key_exists( $field, $value ) ) {
				throw new ValidationException( 'forbidden_commercial_field' );
			}
		}
	}

	private function string_length( string $value ): int {
		return function_exists( 'mb_strlen' ) ? mb_strlen( $value, 'UTF-8' ) : strlen( $value );
	}
}
